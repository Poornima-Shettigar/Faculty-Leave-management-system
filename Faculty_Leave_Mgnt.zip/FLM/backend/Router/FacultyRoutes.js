const express = require("express");
const Faculty = require("../Models/Faculty");

const router = express.Router();

// Add Faculty
router.post("/add", async (req, res) => {
  try {
    const { name, role, email, phone, joinDate, department } = req.body;

    const faculty = new Faculty({
      name,
      role,
      email,
      phone,
      joinDate,
      department
    });

    await faculty.save();
    res.status(200).json({ message: "Faculty added successfully", faculty });
  } catch (err) {
    res.status(500).json({ message: "Server Error" });
  }
});

// Get Faculty List
router.get("/list", async (req, res) => {
  try {
    const faculty = await Faculty.find().populate("department");
    res.status(200).json(faculty);
  } catch (err) {
    res.status(500).json({ message: "Server Error" });
  }
});

module.exports = router;
