const express = require("express");
const cors = require("cors");
const connectDB = require("./config/db.js");
const adminRoutes = require("./Router/AdminRoutes.js");
const departmentRoutes=require("./Router/DepartmentRoutes.js");
const facultyRoutes=require("./Router/FacultyRoutes.js");


const app = express();

app.use(cors({
  origin: "http://localhost:5173",
  methods: ["GET", "POST", "PUT", "DELETE"],
  credentials: true
}));

app.use(express.json());

connectDB();

app.use("/api/admin", adminRoutes);
app.use("/api/department", departmentRoutes);
app.use("/api/faculty", facultyRoutes);
app.listen(5000, () => console.log("Server running on port 5000"));
