const mongoose = require("mongoose");
const Admin = require("./Models/Admin.js");

mongoose.connect("mongodb+srv://shiva:NhxmGt162tahD8mk@cluster1.ktltehj.mongodb.net/?appName=Cluster1");

const insertAdmin = async () => {
  const exists = await Admin.findOne({ email: "admin1@gmail.com" });

  if (exists) {
    console.log("Admin already exists.");
    process.exit();
  }

  await Admin.create({
    name: "Admin",
    email: "admin1@gmail.com",
    password: "123",
    role: "Admin"
  });

  console.log("Default Admin Created: admin1@gmail.com / 123");
  process.exit();
};

insertAdmin();
