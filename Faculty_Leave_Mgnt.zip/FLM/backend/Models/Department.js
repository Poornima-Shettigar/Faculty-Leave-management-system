const mongoose = require("mongoose");

const departmentSchema = new mongoose.Schema({
  name: { type: String, required: true }, 
  hodName: { type: String, required: true },
  noOfCourses: { type: Number, required: true },
  courseNames: { type: [String], default: [] }
});

module.exports = mongoose.model("Department", departmentSchema);
