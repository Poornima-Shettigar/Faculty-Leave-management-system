import React, { useState } from "react";
import "./Login.css";
import bgImage from "../assets/pim.jpg"; // your college image
import logo from "../assets/logo.jpg"; // optional PIM logo


function FacultyLogin() {
 const [formData, setFormData] = useState({ username: "", password: "" });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    alert(`Welcome, ${formData.username || "Admin"}!`);
  };

  return (
    <div
      className="login-page"
      style={{ backgroundImage: `url(${bgImage})` }}
    >
      <div className="login-box">
        <div className="login-header">
          <img src={logo} alt="PIM Logo" className="login-logo" />
          <h2>Faculty Portal Login</h2>
          <p>Welcome, please sign in.</p>
        </div>

        <form className="login-form" onSubmit={handleSubmit}>
          <input
            type="text"
            name="username"
            placeholder="Enter Username"
            value={formData.username}
            onChange={handleChange}
            required
          />
          <input
            type="password"
            name="password"
            placeholder="Enter Password"
            value={formData.password}
            onChange={handleChange}
            required
          />

          <div className="form-options">
            <label>
              <input type="checkbox" /> Remember Me
            </label>
            <a href="#" className="forgot-link">
              Forgot Password?
            </a>
          </div>

          <button type="submit" className="login-btn">
            Login
          </button>
        </form>
      </div>

      <footer className="footer">
        © 2024 Poornaprajna Institute of Management. All Rights Reserved.
      </footer>
    </div>
  );
}

export default FacultyLogin;
