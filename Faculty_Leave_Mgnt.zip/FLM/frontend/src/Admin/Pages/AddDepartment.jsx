import React, { useState } from "react";

function AddDepartment() {
  const [dept, setDept] = useState({
    name: "",
    hodName: "",
    noOfCourses: "",
    courseNames: ""
  });

  const handleChange = (e) => {
    setDept({ ...dept, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const res = await fetch("http://localhost:5000/api/department/add", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        ...dept,
        courseNames: dept.courseNames.split(",")
      })
    });

    const data = await res.json();
    alert(data.message);
  };

  return (
    <div>
      <h2>Add Department</h2>
      <form onSubmit={handleSubmit}>
        <input type="text" name="name" placeholder="Department Name" onChange={handleChange} required />
        <input type="text" name="hodName" placeholder="HOD Name" onChange={handleChange} required />
        <input type="number" name="noOfCourses" placeholder="No of Courses" onChange={handleChange} required />
        <input type="text" name="courseNames" placeholder="Course Names (comma separated)" onChange={handleChange} required />
        <button type="submit">Add Department</button>
      </form>
    </div>
  );
}

export default AddDepartment;
