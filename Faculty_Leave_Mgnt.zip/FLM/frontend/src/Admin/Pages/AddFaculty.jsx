import React, { useEffect, useState } from "react";
import "../styles/AddFaculty.css"



function AddFaculty() {
  const [departments, setDepartments] = useState([]);
  const [faculty, setFaculty] = useState({
    name: "",
    role: "",
    email: "",
    phone: "",
    joinDate: "",
    department: ""
  });

  useEffect(() => {
    fetch("http://localhost:5000/api/department/list")
      .then(res => res.json())
      .then(data => setDepartments(data));
  }, []);

  const handleChange = (e) => {
    setFaculty({ ...faculty, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const res = await fetch("http://localhost:5000/api/faculty/add", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(faculty)
    });

    const data = await res.json();
    alert(data.message);
  };

  return (
    <div className="add-faculty-container">
      <div className="form-card">
        <h2>Add New Faculty</h2>
        <p className="subtitle">Fill out the form to register a faculty member.</p>

        <form onSubmit={handleSubmit} className="faculty-form">
          
          <div className="form-group">
            <label>Faculty Name</label>
            <input type="text" name="name" placeholder="Enter full name" onChange={handleChange} required />
          </div>

          <div className="form-group">
            <label>Role</label>
            <select name="role" onChange={handleChange} required>
              <option value="">Select Role</option>
              <option value="HOD">HOD</option>
              <option value="Teaching">Teaching</option>
              <option value="Non Teaching">Non Teaching</option>
              <option value="Director">Director</option>
            </select>
          </div>

          <div className="form-group">
            <label>Email</label>
            <input type="email" name="email" placeholder="Enter email" onChange={handleChange} required />
          </div>

          <div className="form-group">
            <label>Phone Number</label>
            <input type="text" name="phone" placeholder="Enter phone number" onChange={handleChange} required />
          </div>

          <div className="form-group">
            <label>Join Date</label>
            <input type="date" name="joinDate" onChange={handleChange} required />
          </div>

          <div className="form-group">
            <label>Department</label>
            <select name="department" onChange={handleChange} required>
              <option value="">Select Department</option>
              {departments.map((d) => (
                <option key={d._id} value={d._id}>{d.name}</option>
              ))}
            </select>
          </div>

          <button type="submit" className="submit-btn">Add Faculty</button>
        </form>
      </div>
    </div>
  );
}

export default AddFaculty;
