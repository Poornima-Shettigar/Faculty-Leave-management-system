import React, { useState } from "react";
import "../styles/Topbar.css";
import profileImg from "../../assets/image.png"

function Topbar() {
  const [open, setOpen] = useState(false);

  const logout = () => {
    localStorage.removeItem("user");
    window.location.href = "/";
  };

  return (
    <div className="topbar">
      <h3>Welcome to Admin Dashboard</h3>

      <div className="profile-section">
        <img
          src={profileImg}
          alt="profile"
          className="profile-img"
          onClick={() => setOpen(!open)}
        />

        {open && (
          <div className="profile-dropdown">
            <p onClick={logout}>Logout</p>
            <p onClick={() => alert("Reset password clicked!")}>
              Reset Password
            </p>
          </div>
        )}
      </div>
    </div>
  );
}

export default Topbar;
