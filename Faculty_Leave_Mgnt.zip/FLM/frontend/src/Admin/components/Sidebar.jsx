import React, { useState } from "react";
import { NavLink } from "react-router-dom";
import "../styles/Sidebar.css";

function Sidebar() {
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  const [deptMenuOpen, setDeptMenuOpen] = useState(false);
  const [leaveMenuOpen, setLeaveMenuOpen] = useState(false);
  const [timetableMenuOpen, setTimetableMenuOpen] = useState(false);

  return (
    <div className="sidebar">
      <h2 className="sidebar-title">ADMIN PANEL</h2>

      <ul className="sidebar-menu">

        <li>
          <NavLink to="/admin-dashboard/home">Dashboard</NavLink>
        </li>

        {/* USERS */}
        <li className="menu-parent" onClick={() => setUserMenuOpen(!userMenuOpen)}>
          Manage Users ▾
        </li>

        {userMenuOpen && (
          <ul className="submenu">
            <li><NavLink to="/admin/add-user">Add User</NavLink></li>
            <li><NavLink to="/admin-dashboard/delete-user">Delete/Edit User</NavLink></li>
          </ul>
        )}

        {/* DEPARTMENT */}
        <li className="menu-parent" onClick={() => setDeptMenuOpen(!deptMenuOpen)}>
          Manage Department ▾
        </li>

        {deptMenuOpen && (
          <ul className="submenu">
            <li><NavLink to="/admin-dashboard/add-dept">Add Department</NavLink></li>
            <li><NavLink to="/admin-dashboard/delete-dept">Delete/Edit Department</NavLink></li>
          </ul>
        )}

        {/* LEAVE */}
        <li className="menu-parent" onClick={() => setLeaveMenuOpen(!leaveMenuOpen)}>
          Allocate Leave ▾
        </li>

        {leaveMenuOpen && (
          <ul className="submenu">
            <li><NavLink to="/admin-dashboard/leave-add">Add Leave</NavLink></li>
            <li><NavLink to="/admin-dashboard/leave-delete">Delete/Edit Leave</NavLink></li>
          </ul>
        )}

        {/* TIMETABLE */}
        <li className="menu-parent" onClick={() => setTimetableMenuOpen(!timetableMenuOpen)}>
          Allocate Timetable ▾
        </li>

        {timetableMenuOpen && (
          <ul className="submenu">
            <li><NavLink to="/admin-dashboard/timetable-add">Add Timetable</NavLink></li>
            <li><NavLink to="/admin-dashboard/timetable-delete">Delete/Edit Timetable</NavLink></li>
          </ul>
        )}

      </ul>
    </div>
  );
}

export default Sidebar;
