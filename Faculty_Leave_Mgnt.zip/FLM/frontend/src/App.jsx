import React from "react";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import "./index.css";
import collegeImg from "./assets/pim.jpg";
import Login from "./Admin/Login";
import FacultyLogin from "./Faculty/FacultyLogin";
import HodLogin from "./HOD/HodLogin"; 
import DirectorLogin from "./Director/DirectorLogin";
import AdminDashboard from "./AdminDashboard/AdminDashboard.jsx"
import AddFaculty from "./Admin/Pages/AddFaculty.jsx";
import AddDepartment from "./Admin/Pages/AddDepartment.jsx";
function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={
          <div className="landing-page">
            {/* Header Section */}
            <header className="header">
              <div className="logo">🎓</div>
              <h1 className="college-name">Poornaprajna Institute of Management (PIM), Udupi</h1>
            </header>

            {/* Navigation Bar */}
            <nav className="navbar">
              <ul>
                <li><Link to="/admin-login">Login as Admin</Link></li>
               <li><Link to="/faculty-login">Login as Faculty</Link></li>
                  <li><Link to="/hod-login">Login as HOD</Link></li>
                  <li><Link to="/director-login">Login as Director</Link></li>
        
              </ul>
            </nav>

            {/* College Image Section */}
            <section className="image-section">
              <img src={collegeImg} alt="College" />
              <div className="overlay-text">
                <h2>Welcome to Poornaprajna Institute of Management</h2>
                <p>Empowering Education, Leadership, and Innovation</p>
              </div>
            </section>

            {/* Footer */}
            <footer className="footer">
              <p>© 2025 Poornaprajna Institute of Management | All Rights Reserved</p>
            </footer>
          </div>
        } />

        {/* Admin Login Route */}
        <Route path="/admin-login" element={<Login />} />
         <Route path="/faculty-login" element={<FacultyLogin />} />
        <Route path="/hod-login" element={<HodLogin />} />
        <Route path="/director-login" element={<DirectorLogin />} />
                <Route path="/admin/dashboard" element={<AdminDashboard />} />
                <Route path="/admin/add-user" element={<AddFaculty/>}/>
                <Route path="/admin-dashboard/add-dept" element={<AddDepartment/>}/>

      </Routes>
    </Router>
  );
}

export default App;
